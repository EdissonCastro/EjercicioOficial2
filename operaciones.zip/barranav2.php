<?php
	
	echo "<nav>
        	<ul>
            	<li><a href='pagusuario.php'>Inicio</a></li>
				<li><a href='consultaroperaciones.php'>Consultar operaciones</a></li>
                <li><a href='cerrarsesion.php'>Cerrar sesión</a></li>          
            </ul>
        </nav>";
	
?>