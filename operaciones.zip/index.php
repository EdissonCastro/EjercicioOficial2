<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="estilos.css">
<title>Documento sin título</title>
</head>

<body>
	<div class="contenedor">
		<?php include("encabezado.php"); ?>
        
        <section class="division">
            
                <p>Ingrese a uno de los siguientes enlaces
                para continuar:</p>
                
                <br>
                
                <a href="ingreso.php">Acceder al sistema</a>
                <a href="registro.php">Registrarse</a>
                        
        </section>
        
        
       	<?php include("piepagina.php"); ?>        
    </div>
</body>
</html>