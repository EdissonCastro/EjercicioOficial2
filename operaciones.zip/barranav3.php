<?php
	
	echo "<nav>
        	<ul>
            	<li><a href='pagusuario.php'>Inicio</a></li>
				<li><a href='operaciones.php'>Realizar operaciones</a></li>
                <li><a href='cerrarsesion.php'>Cerrar sesión</a></li>          
            </ul>
        </nav>";
	
?>