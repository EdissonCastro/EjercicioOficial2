<?php
	echo "<footer>
            <em>
                Servicio Nacional de Aprendizaje - SENA <br>
                Mariana Romero, Edisson Castro, Esneider Ardila<br>
                Todos los derechos reservados
            </em>    
        </footer>";
?>