<?php
	
	echo "<nav>
        	<ul>
            	<li><a href='#'>Inicio</a></li>
                <li><a href='cerrarsesion.php'>Cerrar sesión</a></li>          
            </ul>
        </nav>";
	
?>