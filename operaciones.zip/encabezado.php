<?php
	echo "<header>
            <strong>Operaciones matemáticas</strong>
                    
            <p>
                Sistema de información web para el desarrollo
                de operaciones matemáticas
            </p>
        </header>";
?>